

import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Set seed for reproducibility
np.random.seed(42)

# Parameters for the synthetic data
n_segments = 12
segment_length = 150
means = [6, 6, 6, 6, 6,6,6,6,6,1,1,1]  # Mean of each segment
std_dev = [2, 2,2, 2, 2, 2,2, 2,2,2,2,2]  # Standard deviation of each segment
n_outliers = 10
outlier_magnitude = 3 # Magnitude of outliers

# Generate data for each segment
segments = []
for i in range(n_segments):
    segment_data = np.random.normal(means[i], std_dev[i], segment_length)
    segments.append(segment_data)

# Concatenate segments to form the time series
time_series_data = np.concatenate(segments)

# Add outliers at random positions
outlier_indices = np.random.choice(range(len(time_series_data)), n_outliers, replace=False)
time_series_data[outlier_indices] += np.random.choice([-1, 1], n_outliers) * outlier_magnitude

# Convert the generated time series data to a DataFrame
df = pd.DataFrame({
    'Time': np.arange(len(time_series_data)),
    'Value': time_series_data
})

# the directory where I save the CSV
directory = "C:/Users/MSI/Desktop/"
if not os.path.exists(directory):
    os.makedirs(directory)

# Specify the file path
file_path = 'C:/Users/MSI/Desktop/DATAfals1.csv'

# Save the DataFrame to a CSV file
df.to_csv(file_path, index=False)


# Générer le signal de base (sans bruit ni outliers)
base_signal = []
for mean in means:
    base_signal.extend([mean] * segment_length)
base_signal = np.array(base_signal)

# Tracer les données générées
plt.figure(figsize=(10, 6))
# Générer le signal de base (sans bruit ni outliers)
base_signal = np.array([mean for mean in means for _ in range(segment_length)])

# Tracer le signal de base
plt.figure(figsize=(14, 7))
plt.plot(base_signal, label='Signal de Base (sans bruit ni outliers)', color='red')
plt.title('Signal de Base pour la Génération de Séries Temporelles')
plt.plot(df['Time'], df['Value'], label='Time Series Data')
#plt.plot(base_signal, label='Signal de Base (sans bruit ni outliers)', color='red')
plt.xlabel('Time')
plt.ylabel('Amplitude')

plt.title('Generated Data')
plt.legend()
plt.show()
