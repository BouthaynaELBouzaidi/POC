# -*- coding: utf-8 -*-
"""
Created on Sat Dec 23 19:52:33 2023

@author: MSI
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Chargement des données
file_path = 'C:/Users/MSI/Desktop/DATA.csv'  # Assurez-vous que le chemin est correct
df = pd.read_csv(file_path)

# Extraction des valeurs de temps et de la série temporelle
temps = df['Time'].values
valeurs = df['Value'].values

# Estimation simple de θ comme la moyenne des valeurs
theta_estime = np.mean(valeurs)

# Paramètre K pour la perte de Huber
K = 1.5

# la fonction de perte de Huber
def huber_loss(y, theta, K):
    return np.where(np.abs(y - theta) < K, (y - theta) ** 2, 2 * K * np.abs(y - theta) - K**2)

# la dérivée de perte de Huber
def huber_derivative(y, theta, K):
    return np.where(np.abs(y - theta) < K, 2 * (y - theta), 2 * K * np.sign(y - theta))

# Calcul des résidus en utilisant la dérivée de la perte de Huber
residus = huber_derivative(valeurs, theta_estime, K)

# Cumul des résidus
cusum_residus = np.cumsum(residus)

# Calcul de la statistique de test de Wald
n = len(valeurs)
Tn = max([(n / (m * (n - m))) * (cusum_residus[m-1] ** 2) for m in range(1, n)])
point_changement = np.argmax([(n / (m * (n - m))) * (cusum_residus[m-1] ** 2) for m in range(1, n)]) + 1

# Affichage des résultats
print("Statistique de test de Wald:", Tn)
print("Point de changement détecté:", point_changement)

# Visualisation
plt.figure(figsize=(12, 6))
plt.plot(temps, valeurs, label='Données')
plt.axvline(x=temps[point_changement], color='r', linestyle='--', label='Point de Changement')
plt.title('Détection de Point de Changement avec Test de Wald et Perte de Huber personnalisée')
plt.xlabel('Temps')
plt.ylabel('Valeur')
plt.legend()
plt.show()
