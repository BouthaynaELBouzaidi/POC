import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# la graine pour la reproductibilité
np.random.seed(0)

# Parameters for the synthetic data
n_segments = 10
segment_length = 100
means = [10, 20, 1, 10, 20, 10, 25, 10, 0, 15]  # Mean of each segment
std_dev = [2, 3, 1.5, 3, 2, 2, 1, 2, 2, 1]  # Standard deviation of each segment
n_outliers = 10
outlier_magnitude = 20  # Magnitude of outliers



# Générer des données pour chaque segment
segments = []
for i in range(n_segments):
    segment_data = np.random.normal(means[i], std_dev[i], segment_length)
    segments.append(segment_data)

# Concaténer des segments pour former la série chronologique
time_series_data = np.concatenate(segments)

# Ajouter des valeurs aberrantes à des positions aléatoires
outlier_indices = np.random.choice(range(len(time_series_data)), n_outliers, replace=False)
time_series_data[outlier_indices] += np.random.choice([-1, 1], n_outliers) * outlier_magnitude

# Générer le signal de base (sans bruit ni outliers)
base_signal = []
for mean in means:
    base_signal.extend([mean] * segment_length)
base_signal = np.array(base_signal)


# Convertir les données de séries chronologiques générées en DataFrame

df = pd.DataFrame({
    'Time': np.arange(len(time_series_data)),
    'Value': time_series_data
})

# le répertoire où j’enregistre le fichier CSV
directory = "C:/Users/MSI/Desktop/"
if not os.path.exists(directory):
    os.makedirs(directory)

#  spécifiez le chemin d'accès
file_path = 'C:/Users/MSI/Desktop/DATA10.csv'

#Enregistrer le DataFrame dans un fichier CSV
df.to_csv(file_path, index=False)
# Tracer les données générées
plt.figure(figsize=(10, 6))
plt.plot(df['Time'], df['Value'], label='Time Series Data')
plt.plot(base_signal, label='Signal de Base (sans bruit ni outliers)', color='red')
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Generated Time Series with Outliers')
plt.legend()
plt.show()
