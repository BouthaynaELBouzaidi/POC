
import matplotlib.pyplot as plt
import numpy as np

def gamma(y, theta, loss_function):
    if loss_function == "L2":
        return (y - theta) ** 2
    elif loss_function == "absolute_error":
        return np.abs(y - theta)
    elif loss_function == "huber":
        K = 1
        return np.where(np.abs(y - theta) < K, (y - theta) ** 2, 2 * K * np.abs(y - theta) - K**2)
    elif loss_function == "biweight":
        K = 3
        return np.where(np.abs(y - theta) < K, (y - theta) ** 2, K**2)
    elif loss_function == "quantile_loss":
        u = 0.5 
        r = y - theta
        return np.where(y > theta, 2 * u * r, 2 * (1 - u) * (-r))

# les points faux positifs (FP) et vrais positifs (TP) de trois fonctions
fp = np.array([0.7, 1, 1.6, 3, 5])
tp1 = np.array([0, 4, 8, 7, 9.2])
tp2 = np.array([0, 3.8, 4.5, 5.9, 8])
tp3 = np.array([0, 8, 10, 12, 14])



# Calcul des erreurs pour chaque fonction
tp1_error = gamma(tp1, fp, "biweight")
tp2_error = gamma(tp2, fp, "L2")
tp3_error = gamma(tp3,fp, "absolute_error")

# Tracer les courbes pour chaque fonction
plt.figure(figsize=(10, 6))
plt.plot(fp, tp1_error, label='Biweight ', marker='o')
plt.plot(fp, tp2_error, label='L2', marker='s')
plt.plot(fp, tp3_error, label=' Absolute Error', marker='^')

# Ajout des étiquettes et du titre
plt.xlabel('FP (Faux Positifs)')
plt.ylabel('TP (True Positifs)')
plt.title('GSE11976 (TF=0.7)')

# Ajout de la grille et de la légende
plt.legend()
plt.grid(True)

# Affichage du graphique
plt.show()
