

# Import necessary libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Load the data from the CSV file
csv_file = 'C:/Users/MSI/Desktop/DATAADNf.csv'  # Adjust the file path as needed
data = pd.read_csv(csv_file)

# Extract the genomic loci and copy number data
c_data = data['Copy Number'].values

# Define the biweight loss function
def biweight_loss(y, theta, K):
    diff = y - theta
    condition = np.abs(diff) < K
    return np.where(condition, diff ** 2, K**2)

# Define the R-FPOP algorithm
def rfpop_algorithm(y, K):
    n = len(y)
    # Define the penalty dynamically based on the number of data points
    beta = 1 * np.log(n)  # Example of dynamic penalty increasing with n
    Q = np.zeros(n + 1)
    tau = np.zeros(n + 1, dtype=int)

    # Function to compute the best theta for a given segment
    def best_theta(segment):
        theta_vals = np.linspace(min(segment), max(segment), num=100)
        costs = np.array([sum(biweight_loss(segment, theta, K)) for theta in theta_vals])
        return theta_vals[np.argmin(costs)]

    # Loop through each data point
    for t in range(1, n + 1):
        Qt = np.inf
        for k in range(t):
            segment = y[k:t]
            theta = best_theta(segment)
            cost = sum(biweight_loss(segment, theta, K) + beta)
            # Qt_candidate now includes the loss function for the current observation
            gamma_value = biweight_loss(y[t-1], theta, K)
            Qt_candidate = Q[k] + cost + beta + gamma_value
            if Qt_candidate < Qt:
                Qt = Qt_candidate
                tau[t] = k
        Q[t] = Qt

    # Backtrack to find the changepoints
    changepoints = []
    t = n
    while t > 0:
        if tau[t] != 0 and tau[t] not in changepoints:
            changepoints.append(tau[t])
        t = tau[t]
    return sorted(changepoints)

# Estimation of K based on noise standard deviation
# Using Median Absolute Deviation (MAD) to estimate noise variance
mad = np.median(np.abs(c_data - np.median(c_data))) / 0.6745
K = 1 * mad  # Adjust based on the standard deviation of noise

# Execute the algorithm
changepoints = rfpop_algorithm(c_data, K)

# Display detected changepoint indices
print("Detected changepoint indices:", changepoints)

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(c_data, label='Simulated Copy Number Data')
for cp in changepoints:
    plt.axvline(x=cp, color='r', linestyle='--', label='Changepoint' if cp == changepoints[0] else None)
plt.xlabel('Genomic Loci')
plt.ylabel('Copy Number')
plt.title('tumor fraction=1')
plt.legend()
plt.show()

