
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#Données simulées de numéro de copie d’ADN
np.random.seed(42)  # pour la reproductibilité

# Définir les breakpoints et les niveaux de nombre de copies correspondants
breakpoints = [0, 2200, 6100, 10000]
copy_numbers = [2, 3, 2]  # Normal, chromosome dupliqué, uniparental disomy

# Simuler le nombre total de copies (c)
c_data = np.concatenate([
    np.random.normal(cn, 1, end - start) 
    for (start, end, cn) in zip(breakpoints[:-1], breakpoints[1:], copy_numbers)
])


# Création d’un DataFrame pour les données simulées
df = pd.DataFrame({
    'Genomic Loci': np.arange(len(c_data)),
    'Copy Number': c_data
})

# Définir le nom du fichier CSV
csv_file = 'C:/Users/MSI/Desktop/DATAADNf.csv'

# Save the DataFrame to a CSV file
df.to_csv(csv_file, index=False)

csv_file
# Créer un tableau d'indices pour l'axe x
x = np.arange(len(c_data))

# Tracer les données en utilisant scatter
plt.figure(figsize=(14, 6))
plt.scatter(x, c_data, label='Total Copy Number (c)')

plt.title('Scatter Plot of Simulated Copy Number Data')
plt.xlabel('Genomic Loci')
plt.ylabel('Copy Number')
plt.legend()
plt.show()






