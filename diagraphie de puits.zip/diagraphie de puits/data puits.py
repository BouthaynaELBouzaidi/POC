
import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Set seed for reproducibility
np.random.seed(0)

# Parameters for the synthetic data
n_segments = 10
segment_length = 200 
means = [15, 15, 15, 25, 25, 33, 10, 25, 15, 15]  # Mean of each segment
std_dev = [3, 2, 3, 5, 4.5, 4, 4, 4, 2, 4]  # Standard deviation of each segment
n_outliers = 10
outlier_magnitude = 20  # Magnitude of outliers

# Generate data for each segment
segments = []
for i in range(n_segments):
    segment_data = np.random.normal(means[i], std_dev[i], segment_length)
    segments.append(segment_data)

# Concatenate segments to form the time series
time_series_data = np.concatenate(segments)

# Add outliers at random positions
outlier_indices = np.random.choice(range(len(time_series_data)), n_outliers, replace=False)
time_series_data[outlier_indices] += np.random.choice([-1, 1], n_outliers) * outlier_magnitude

# Convert the generated time series data to a DataFrame
df = pd.DataFrame({
    'Time': np.arange(len(time_series_data)),
    'Value': time_series_data
})

# the directory where I save the CSV
directory = "C:/Users/MSI/Desktop/"
if not os.path.exists(directory):
    os.makedirs(directory)

# Specify the file path
file_path = 'C:/Users/MSI/Desktop/DATApuits.csv'

# Save the DataFrame to a CSV file
df.to_csv(file_path, index=False)

# Générer le signal de base (sans bruit ni outliers)
base_signal = []
for mean in means:
    base_signal.extend([mean] * segment_length)
base_signal = np.array(base_signal)

# Tracer les données générées
plt.figure(figsize=(10, 6))
plt.scatter(df['Time'], df['Value'], label='Time Series Data')
#plt.plot(base_signal, label='Signal de Base (sans bruit ni outliers)', color='red')
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Generated Time Series with Outliers')
plt.legend()
plt.show()
