
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Charger les données à partir du fichier CSV
file_path = "C:/Users/MSI/Desktop/DATA20.csv"  
data = pd.read_csv(file_path)

# Extraire les colonnes 'Time' et 'Value' du DataFrame
t = data['Time'].values
y = data['Value'].values



# Fonction de perte biweight
def biweight_loss(y, theta, K):
    diff = y - theta
    condition = np.abs(diff) < K
    return np.where(condition, diff ** 2, K**2)

# Algorithme de détection des points de changement
def rfpop_algorithm(y, K):
    n = len(y)
    # Définir la pénalité en fonction du nombre de données, comme spécifié dans l'article
    beta = 15 * np.log(n)  # exemple de pénalité dynamique qui augmente avec n
    Q = np.zeros(n + 1)
    tau = np.zeros(n + 1, dtype=int)

    # Calculer le meilleur theta pour chaque segment potentiel
    def best_theta(segment):
        theta_vals = np.linspace(min(segment), max(segment), num=100)
        costs = np.array([sum(biweight_loss(segment, theta, K)) for theta in theta_vals])
        return theta_vals[np.argmin(costs)]

    # Boucle pour chaque point de données
    for t in range(1, n + 1):
        Qt = np.inf
        for k in range(t):
            segment = y[k:t]
            theta = best_theta(segment)
            cost = sum(biweight_loss(segment, theta, K) + beta)
            # Qt_candidate inclut maintenant la fonction de perte pour l'observation actuelle
            gamma_value = biweight_loss(y[t-1], theta, K)
            Qt_candidate = Q[k] + cost + beta + gamma_value
            if Qt_candidate < Qt:
                Qt = Qt_candidate
                tau[t] = k
        Q[t] = Qt

    # Retour en arrière pour trouver les points de changement
    changepoints = []
    t = n
    while t > 0:
        if tau[t] != 0 and tau[t] not in changepoints:
            changepoints.append(tau[t])
        t = tau[t]
    return sorted(changepoints)

# Estimation de K en fonction de l'écart-type du bruit
# Utilisation de la médiane absolue déviée (MAD) pour estimer la variance du bruit
mad = np.median(np.abs(y - np.median(y))) / 0.6745
K = 1 * mad  # ajuster en fonction de l'écart-type du bruit

# Exécution de l'algorithme
changepoints = rfpop_algorithm(y, K)

# Afficher les points de changement détectés
print("Detected changepoint indices:", changepoints)
print("Corresponding time values of changepoints:", t[changepoints])

# Tracer les résultats
plt.figure(figsize=(10, 6))
plt.plot(t, y, label='Time Series Data')
for cp in changepoints:
    plt.axvline(x=t[cp], color='r', linestyle='--', label='Changepoint' if cp == changepoints[0] else None)
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Changepoint Detection with R-FPOP')
plt.legend()
plt.show()
