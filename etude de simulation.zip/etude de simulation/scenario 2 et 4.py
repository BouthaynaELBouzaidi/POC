
import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
# Fonction de perte biweight
def biweight_loss(y, theta, K):
    diff = y - theta
    condition = np.abs(diff) < K
    return np.where(condition, diff ** 2, K**2)

# Algorithme de détection des points de changement
def rfpop_algorithm(y, K):
    n = len(y)
    # Définir la pénalité en fonction du nombre de données, comme spécifié dans l'article
    beta = 100 * np.log(n)  # exemple de pénalité dynamique qui augmente avec n
    Q = np.zeros(n + 1)
    tau = np.zeros(n + 1, dtype=int)

    # Calculer le meilleur theta pour chaque segment potentiel
    def best_theta(segment):
        theta_vals = np.linspace(min(segment), max(segment), num=100)
        costs = np.array([sum(biweight_loss(segment, theta, K)) for theta in theta_vals])
        return theta_vals[np.argmin(costs)]

    # Boucle pour chaque point de données
    for t in range(1, n + 1):
        Qt = np.inf
        for k in range(t):
            segment = y[k:t]
            theta = best_theta(segment)
            cost = sum(biweight_loss(segment, theta, K) + beta)
            # Qt_candidate inclut maintenant la fonction de perte pour l'observation actuelle
            gamma_value = biweight_loss(y[t-1], theta, K)
            Qt_candidate = Q[k] + cost + beta + gamma_value
            if Qt_candidate < Qt:
                Qt = Qt_candidate
                tau[t] = k
        Q[t] = Qt

    # Retour en arrière pour trouver les points de changement
    changepoints = []
    t = n
    while t > 0:
        if tau[t] != 0 and tau[t] not in changepoints:
            changepoints.append(tau[t])
        t = tau[t]
    return sorted(changepoints)


# Charger les données à partir des fichiers CSV pour les deux ensembles de données
file_path1 = "C:/Users/MSI/Desktop/DATA500.csv"  
file_path2 = "C:/Users/MSI/Desktop/DATA140.csv"
data1 = pd.read_csv(file_path1)
data2 = pd.read_csv(file_path2)

# Extraire les colonnes 'Time' et 'Value' pour les deux ensembles de données
t1 = data1['Time'].values
y1 = data1['Value'].values
t2 = data2['Time'].values
y2 = data2['Value'].values

# Exécution de l'algorithme RFPOP pour les deux ensembles de données
# Pour des raisons de simplicité, je vais utiliser les mêmes paramètres K et beta pour les deux ensembles
mad1 = np.median(np.abs(y1 - np.median(y1))) / 0.6745
mad2 = np.median(np.abs(y2 - np.median(y2))) / 0.6745
K1 = 3 * mad1
K2 = 3 * mad2
changepoints1 = rfpop_algorithm(y1, K1)
changepoints2 = rfpop_algorithm(y2, K2)

# Calculer les moyennes des segments détectés pour les deux ensembles de données
segment_means1 = [np.mean(y1[:changepoints1[0]])] + [np.mean(y1[changepoints1[i-1]:changepoints1[i]]) for i in range(1, len(changepoints1))] + [np.mean(y1[changepoints1[-1]:])]
segment_means2 = [np.mean(y2[:changepoints2[0]])] + [np.mean(y2[changepoints2[i-1]:changepoints2[i]]) for i in range(1, len(changepoints2))] + [np.mean(y2[changepoints2[-1]:])]

# Tracer les deux ensembles de données sur le même graphique
plt.figure(figsize=(12, 8))

# Tracer les données et les moyennes des segments du premier ensemble
plt.subplot(2, 1, 1)
plt.scatter(t1, y1, color='black', s=10)
for i, mean in enumerate(segment_means1):
    start = t1[changepoints1[i-1]] if i > 0 else t1[0]
    end = t1[changepoints1[i]] if i < len(changepoints1) else t1[-1]
    plt.hlines(mean, xmin=start, xmax=end, colors='red', linestyles='-')

# Tracer les données et les moyennes des segments du second ensemble
plt.subplot(2, 1, 2)
plt.scatter(t2, y2, color='black', s=10)
for i, mean in enumerate(segment_means2):
    start = t2[changepoints2[i-1]] if i > 0 else t2[0]
    end = t2[changepoints2[i]] if i < len(changepoints2) else t2[-1]
    plt.hlines(mean, xmin=start, xmax=end, colors='red', linestyles='-')

plt.tight_layout()
plt.show()
