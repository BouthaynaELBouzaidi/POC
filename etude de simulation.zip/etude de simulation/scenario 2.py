# -*- coding: utf-8 -*-
"""
Created on Tue Dec 26 15:58:31 2023

@author: MSI
"""


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Charger les données à partir du fichier CSV
file_path = "C:/Users/MSI/Desktop/DATA500.csv"  
data = pd.read_csv(file_path)

# Extraire les colonnes 'Time' et 'Value' du DataFrame
t = data['Time'].values
y = data['Value'].values

# Fonction de perte biweight
def biweight_loss(y, theta, K):
    diff = y - theta
    condition = np.abs(diff) < K
    return np.where(condition, diff ** 2, K**2)

# Algorithme de détection des points de changement
def rfpop_algorithm(y, K):
    n = len(y)
    # Définir la pénalité en fonction du nombre de données, comme spécifié dans l'article
    beta = 100 * np.log(n)  # exemple de pénalité dynamique qui augmente avec n
    Q = np.zeros(n + 1)
    tau = np.zeros(n + 1, dtype=int)

    # Calculer le meilleur theta pour chaque segment potentiel
    def best_theta(segment):
        theta_vals = np.linspace(min(segment), max(segment), num=100)
        costs = np.array([sum(biweight_loss(segment, theta, K)) for theta in theta_vals])
        return theta_vals[np.argmin(costs)]

    # Boucle pour chaque point de données
    for t in range(1, n + 1):
        Qt = np.inf
        for k in range(t):
            segment = y[k:t]
            theta = best_theta(segment)
            cost = sum(biweight_loss(segment, theta, K) + beta)
            # Qt_candidate inclut maintenant la fonction de perte pour l'observation actuelle
            gamma_value = biweight_loss(y[t-1], theta, K)
            Qt_candidate = Q[k] + cost + beta + gamma_value
            if Qt_candidate < Qt:
                Qt = Qt_candidate
                tau[t] = k
        Q[t] = Qt

    # Retour en arrière pour trouver les points de changement
    changepoints = []
    t = n
    while t > 0:
        if tau[t] != 0 and tau[t] not in changepoints:
            changepoints.append(tau[t])
        t = tau[t]
    return sorted(changepoints)

# Estimation de K en fonction de l'écart-type du bruit
# Utilisation de la médiane absolue déviée (MAD) pour estimer la variance du bruit
mad = np.median(np.abs(y - np.median(y))) / 0.6745
K = 3 * mad  # ajuster en fonction de l'écart-type du bruit

# Exécution de l'algorithme RFPOP pour obtenir les points de changement
changepoints = rfpop_algorithm(y, K)

# Calculer les moyennes des segments détectés
segment_means = [np.mean(y[:changepoints[0]])]  # La moyenne du premier segment
for i in range(1, len(changepoints)):
    segment_means.append(np.mean(y[changepoints[i-1]:changepoints[i]]))
segment_means.append(np.mean(y[changepoints[-1]:]))  # La moyenne du dernier segment

# Tracer les résultats avec les données en points et les moyennes des segments en lignes rouges
plt.figure(figsize=(10, 6))
plt.scatter(t, y, color='black', s=10)  # Données en points

# Tracer les lignes horizontales pour les moyennes des segments
for i, mean in enumerate(segment_means):
    start = t[changepoints[i-1]] if i > 0 else t[0]
    end = t[changepoints[i]] if i < len(changepoints) else t[-1]
    plt.hlines(mean, xmin=start, xmax=end, colors='red', linestyles='-', label='Segment Mean' if i == 0 else "")

plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Changepoint Detection with RFPOP')
plt.legend()
plt.show()
