
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Assurez-vous que le fichier DATA.csv est téléchargé et accessible dans l'environnement de travail actuel.
# Remplacez 'file_path' par le chemin d'accès correct sur votre système ou serveur.
file_path = "C:/Users/MSI/Desktop/DATA.csv"
data = pd.read_csv(file_path)

# Extraire les colonnes 'Time' et 'Value' du DataFrame
t = data['Time'].values
y = data['Value'].values

def gamma(y, theta, loss_function, u=0.1):  # Ajoutons une valeur par défaut pour u
    if loss_function == "square_error":
        return (y - theta) ** 2
    elif loss_function == "absolute_error":
        return np.abs(y - theta)
    elif loss_function == "huber":
        K = 1
        return np.where(np.abs(y - theta) < K, (y - theta) ** 2, 2 * K * np.abs(y - theta) - K**2)
    elif loss_function == "biweight":
        K = 3
        return np.where(np.abs(y - theta) < K, (y - theta) ** 2, K**2)
    elif loss_function == "quantile_loss":
        r = y - theta
        return np.where(y > theta, u * r, (1 - u) * (-r))
    else:
        raise ValueError("Invalid loss function")

# Générer une plage de valeurs y à titre d’exemple
theta_value = np.mean(y)  # la moyenne des valeurs y comme valeur de theta

# Plot each loss function
loss_functions = ["square_error", "absolute_error", "huber", "biweight"]

plt.figure(figsize=(12, 8))

for loss_function in loss_functions:
    loss_values = gamma(y, theta_value, loss_function)  # Utilisez y, pas y_values
    plt.plot(t, loss_values, label=loss_function)  # Utilisez scatter pour visualiser par rapport au temps

plt.title('Loss Functions')
plt.xlabel('Time')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)
plt.show()
