
import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Set seed for reproducibility
np.random.seed(0)

# Parameters for the synthetic data

n_segments = 40
segment_length = 100
means = np.random.choice(range(5, 10), n_segments)  # Mean of each segment, random between 10 and 20
std_dev = np.random.choice(range(1, 4), n_segments)  # Standard deviation of each segment
n_outliers = 10
outlier_magnitude = 20  # Magnitude of outliers

# Generate data for each segment
segments = []
for i in range(n_segments):
    segment_data = np.random.normal(means[i], std_dev[i], segment_length)
    segments.append(segment_data)

# Générer le signal de base (sans bruit ni outliers)
base_signal = []
for mean in means:
    base_signal.extend([mean] * segment_length)
base_signal = np.array(base_signal)

# Concatenate segments to form the time series
time_series_data = np.concatenate(segments)

# Add outliers at random positions
outlier_indices = np.random.choice(range(len(time_series_data)), n_outliers, replace=False)
time_series_data[outlier_indices] += np.random.choice([-1, 1], n_outliers) * outlier_magnitude

# Convert the generated time series data to a DataFrame
df = pd.DataFrame({
    'Time': np.arange(len(time_series_data)),
    'Value': time_series_data
})

# the directory where I save the CSV
directory = "C:/Users/MSI/Desktop/"
if not os.path.exists(directory):
    os.makedirs(directory)

# Specify the file path
file_path = 'C:/Users/MSI/Desktop/DATA400.csv'

# Save the DataFrame to a CSV file
df.to_csv(file_path, index=False)


# Statistiques descriptives
print("Statistiques Descriptives:")
print(df['Value'].describe())

# Histogramme pour la distribution des valeurs
plt.figure(figsize=(10, 6))
plt.hist(df['Value'], bins=30, alpha=0.7)
plt.title("Histogramme des Valeurs de la Série Temporelle")
plt.xlabel("Valeur")
plt.ylabel("Fréquence")
plt.show()

# Boxplot pour visualiser les outliers
plt.figure(figsize=(10, 6))
plt.boxplot(df['Value'], vert=False)
plt.title("Boxplot des Valeurs de la Série Temporelle")
plt.xlabel("Valeur")
plt.show()

# Tracer les outliers sur le graphique de la série temporelle
plt.figure(figsize=(10, 6))
plt.plot(df['Time'], df['Value'], label='Time Series Data')
plt.plot(base_signal, label='Signal de Base (sans bruit ni outliers)', color='red')
plt.scatter(df['Time'][outlier_indices], df['Value'][outlier_indices], color='red', label='Outliers')
plt.xlabel('Time')
plt.ylabel('Value')
plt.title('Generated Time Series with Outliers')
plt.legend()
plt.show()
